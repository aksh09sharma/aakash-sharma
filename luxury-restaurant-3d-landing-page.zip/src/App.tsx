import { useEffect } from 'react';
import HeroSection from './components/HeroSection';
import ExperienceSection from './components/ExperienceSection';
import MenuSection from './components/MenuSection';
import ReservationSection from './components/ReservationSection';
import FooterSection from './components/FooterSection';
import CustomCursor from './components/CustomCursor';

export default function App() {
  // Disable default cursor
  useEffect(() => {
    document.body.style.cursor = 'none';
    return () => { document.body.style.cursor = 'auto'; };
  }, []);

  return (
    <div className="relative bg-[#0D0D0D] min-h-screen overflow-x-hidden">
      <CustomCursor />
      <HeroSection />
      <ExperienceSection />
      {/* Divider between sections */}
      <div
        className="w-full h-px"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.15), transparent)' }}
      />
      <MenuSection />
      <div
        className="w-full h-px"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.15), transparent)' }}
      />
      <ReservationSection />
      <FooterSection />
    </div>
  );
}
