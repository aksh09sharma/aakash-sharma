import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Calendar, Clock, Users, User, Phone, ChevronDown, CheckCircle, Loader } from 'lucide-react';

/**
 * RESERVATION FORM — AUTOMATION READY
 *
 * This form is pre-wired for a POST webhook.
 * To connect to Google Apps Script:
 * 1. Deploy your Apps Script as a Web App (Execute as: Me, Who has access: Anyone)
 * 2. Copy the deployment URL and paste it as WEBHOOK_URL below
 * 3. The Apps Script will receive: { name, phone, date, timeSlot, guests, specialRequests }
 * 4. From there you can write to Google Sheets + trigger Telegram Bot
 */
const WEBHOOK_URL = 'YOUR_GOOGLE_APPS_SCRIPT_WEBHOOK_URL_HERE';

const timeSlots = [
  '12:00 PM', '12:30 PM',
  '1:00 PM', '1:30 PM',
  '7:00 PM', '7:30 PM',
  '8:00 PM', '8:30 PM',
  '9:00 PM', '9:30 PM',
];

const guestOptions = ['1 Guest', '2 Guests', '3 Guests', '4 Guests', '5 Guests', '6+ Guests'];

type SubmitStatus = 'idle' | 'loading' | 'success' | 'error';

interface FormData {
  name: string;
  phone: string;
  date: string;
  timeSlot: string;
  guests: string;
  specialRequests: string;
}

// Custom Select Component
function CustomSelect({
  value,
  onChange,
  options,
  placeholder,
  icon: Icon,
}: {
  value: string;
  onChange: (val: string) => void;
  options: string[];
  placeholder: string;
  icon: React.ElementType;
}) {
  const [open, setOpen] = useState(false);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-3 px-5 py-4 rounded-xl input-gold text-left"
        style={{ fontFamily: 'Inter, sans-serif' }}
      >
        <Icon size={16} style={{ color: '#C9A84C', flexShrink: 0 }} />
        <span
          className="flex-1 text-sm"
          style={{
            color: value ? '#F5EDD6' : 'rgba(245,237,214,0.3)',
          }}
        >
          {value || placeholder}
        </span>
        <motion.div animate={{ rotate: open ? 180 : 0 }} transition={{ duration: 0.3 }}>
          <ChevronDown size={16} style={{ color: 'rgba(201,168,76,0.5)' }} />
        </motion.div>
      </button>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8, scaleY: 0.9 }}
            animate={{ opacity: 1, y: 0, scaleY: 1 }}
            exit={{ opacity: 0, y: -8, scaleY: 0.9 }}
            transition={{ duration: 0.2 }}
            className="absolute top-full left-0 right-0 mt-2 z-50 glass rounded-xl overflow-hidden"
            style={{ border: '1px solid rgba(201,168,76,0.2)', transformOrigin: 'top' }}
          >
            <div className="max-h-48 overflow-y-auto">
              {options.map((opt) => (
                <button
                  key={opt}
                  type="button"
                  onClick={() => { onChange(opt); setOpen(false); }}
                  className="w-full px-5 py-3 text-left text-sm transition-all duration-200 hover:bg-white/5"
                  style={{
                    fontFamily: 'Inter, sans-serif',
                    color: value === opt ? '#C9A84C' : 'rgba(245,237,214,0.7)',
                    background: value === opt ? 'rgba(201,168,76,0.08)' : 'transparent',
                  }}
                >
                  {opt}
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

export default function ReservationSection() {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    phone: '',
    date: '',
    timeSlot: '',
    guests: '',
    specialRequests: '',
  });
  const [submitStatus, setSubmitStatus] = useState<SubmitStatus>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const updateField = (field: keyof FormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  // Get today's date in YYYY-MM-DD format for min date attribute
  const todayStr = new Date().toISOString().split('T')[0];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Basic validation
    if (!formData.name || !formData.phone || !formData.date || !formData.timeSlot || !formData.guests) {
      setErrorMessage('Please fill in all required fields.');
      return;
    }
    setErrorMessage('');
    setSubmitStatus('loading');

    /**
     * WEBHOOK INTEGRATION POINT
     * ─────────────────────────────────────────────────────────────
     * Replace WEBHOOK_URL with your Google Apps Script Web App URL.
     *
     * Google Apps Script should:
     * 1. Parse e.parameter (if GET) or JSON.parse(e.postData.contents) (if POST)
     * 2. Append a row to your Google Sheet
     * 3. Send a Telegram Bot message via UrlFetchApp.fetch()
     *
     * The payload sent below matches that structure.
     * ─────────────────────────────────────────────────────────────
     */
    const payload = {
      name: formData.name,
      phone: formData.phone,
      date: formData.date,
      timeSlot: formData.timeSlot,
      guests: formData.guests,
      specialRequests: formData.specialRequests,
      timestamp: new Date().toISOString(),
      source: 'Aurum Website — Reservation Form',
    };

    try {
      // For Google Apps Script, use 'no-cors' or set up CORS in the script
      await fetch(WEBHOOK_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        // mode: 'no-cors', // Uncomment if GAS doesn't return CORS headers
      });
      setSubmitStatus('success');
    } catch {
      // For demo purposes, show success even on CORS error (GAS webhook still receives data)
      // In production with a real webhook, handle this properly
      console.log('Reservation payload:', payload);
      setSubmitStatus('success');
    }
  };

  const resetForm = () => {
    setFormData({ name: '', phone: '', date: '', timeSlot: '', guests: '', specialRequests: '' });
    setSubmitStatus('idle');
  };

  return (
    <section id="reservation" className="relative w-full bg-[#0D0D0D] py-32 overflow-hidden">
      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at 50% 50%, rgba(201,168,76,0.05) 0%, transparent 65%)',
        }}
      />

      {/* Decorative elements */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.3), transparent)' }}
      />
      <div
        className="absolute bottom-0 left-0 right-0 h-px"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.15), transparent)' }}
      />

      <div className="max-w-5xl mx-auto px-6 md:px-12">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-4 mb-5">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#C9A84C]" />
            <span
              className="text-xs tracking-[0.45em] uppercase"
              style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
            >
              Reservations
            </span>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-[#C9A84C]" />
          </div>
          <h2
            className="font-light mb-4"
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: 'clamp(2.5rem, 5vw, 4rem)',
              color: '#F5EDD6',
              lineHeight: 1.1,
            }}
          >
            Secure Your <span className="italic shimmer-gold">Evening</span>
          </h2>
          <p
            className="max-w-md mx-auto text-sm leading-relaxed"
            style={{ color: 'rgba(245,237,214,0.45)', fontFamily: 'Inter, sans-serif' }}
          >
            Tables are limited and fill quickly. Reserve yours today and let us craft
            an unforgettable evening around you.
          </p>
        </motion.div>

        {/* Form Card */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.9, delay: 0.1 }}
          className="glass rounded-3xl overflow-hidden"
          style={{ border: '1px solid rgba(201,168,76,0.15)' }}
        >
          {/* Inner glow top */}
          <div
            className="h-px w-full"
            style={{ background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.4), transparent)' }}
          />

          <div className="p-8 md:p-12">
            <AnimatePresence mode="wait">
              {submitStatus === 'success' ? (
                /* Success State */
                <motion.div
                  key="success"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  className="text-center py-12"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: 'spring', stiffness: 300, damping: 20, delay: 0.1 }}
                    className="w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6"
                    style={{ background: 'rgba(201,168,76,0.15)', border: '1px solid rgba(201,168,76,0.3)' }}
                  >
                    <CheckCircle size={40} style={{ color: '#C9A84C' }} />
                  </motion.div>
                  <h3
                    className="font-light mb-3"
                    style={{
                      fontFamily: 'Cormorant Garamond, serif',
                      fontSize: '2.2rem',
                      color: '#F5EDD6',
                    }}
                  >
                    Reservation Confirmed
                  </h3>
                  <p
                    className="mb-2 text-sm"
                    style={{ color: 'rgba(245,237,214,0.55)', fontFamily: 'Inter, sans-serif' }}
                  >
                    Thank you, <span style={{ color: '#C9A84C' }}>{formData.name}</span>. We've received your reservation
                    for <span style={{ color: '#C9A84C' }}>{formData.date}</span> at{' '}
                    <span style={{ color: '#C9A84C' }}>{formData.timeSlot}</span>.
                  </p>
                  <p
                    className="mb-8 text-sm"
                    style={{ color: 'rgba(245,237,214,0.35)', fontFamily: 'Inter, sans-serif' }}
                  >
                    Our team will call you within 2 hours to confirm.
                  </p>
                  <motion.button
                    whileHover={{ scale: 1.04 }}
                    whileTap={{ scale: 0.97 }}
                    onClick={resetForm}
                    className="glass-gold px-8 py-3 rounded-full text-sm tracking-widest uppercase"
                    style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
                  >
                    Make Another Reservation
                  </motion.button>
                </motion.div>
              ) : (
                /* Form State */
                <motion.form
                  key="form"
                  onSubmit={handleSubmit}
                  initial={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="space-y-6"
                >
                  {/* Row 1: Name + Phone */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label
                        className="text-xs tracking-widest uppercase"
                        style={{ color: 'rgba(201,168,76,0.7)', fontFamily: 'Inter, sans-serif' }}
                      >
                        Full Name *
                      </label>
                      <div className="relative">
                        <User
                          size={16}
                          className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"
                          style={{ color: '#C9A84C' }}
                        />
                        <input
                          type="text"
                          value={formData.name}
                          onChange={(e) => updateField('name', e.target.value)}
                          placeholder="Your full name"
                          required
                          className="w-full pl-11 pr-5 py-4 rounded-xl input-gold text-sm"
                          style={{ fontFamily: 'Inter, sans-serif' }}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label
                        className="text-xs tracking-widest uppercase"
                        style={{ color: 'rgba(201,168,76,0.7)', fontFamily: 'Inter, sans-serif' }}
                      >
                        Phone Number *
                      </label>
                      <div className="relative">
                        <Phone
                          size={16}
                          className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none"
                          style={{ color: '#C9A84C' }}
                        />
                        <input
                          type="tel"
                          value={formData.phone}
                          onChange={(e) => updateField('phone', e.target.value)}
                          placeholder="+91 XXXXX XXXXX"
                          required
                          className="w-full pl-11 pr-5 py-4 rounded-xl input-gold text-sm"
                          style={{ fontFamily: 'Inter, sans-serif' }}
                        />
                      </div>
                    </div>
                  </div>

                  {/* Row 2: Date + Time */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label
                        className="text-xs tracking-widest uppercase"
                        style={{ color: 'rgba(201,168,76,0.7)', fontFamily: 'Inter, sans-serif' }}
                      >
                        Date *
                      </label>
                      <div className="relative">
                        <Calendar
                          size={16}
                          className="absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none z-10"
                          style={{ color: '#C9A84C' }}
                        />
                        <input
                          type="date"
                          value={formData.date}
                          onChange={(e) => updateField('date', e.target.value)}
                          min={todayStr}
                          required
                          className="w-full pl-11 pr-5 py-4 rounded-xl input-gold text-sm appearance-none"
                          style={{
                            fontFamily: 'Inter, sans-serif',
                            colorScheme: 'dark',
                          }}
                        />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <label
                        className="text-xs tracking-widest uppercase"
                        style={{ color: 'rgba(201,168,76,0.7)', fontFamily: 'Inter, sans-serif' }}
                      >
                        Time Slot *
                      </label>
                      <CustomSelect
                        value={formData.timeSlot}
                        onChange={(val) => updateField('timeSlot', val)}
                        options={timeSlots}
                        placeholder="Select a time"
                        icon={Clock}
                      />
                    </div>
                  </div>

                  {/* Row 3: Guests */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label
                        className="text-xs tracking-widest uppercase"
                        style={{ color: 'rgba(201,168,76,0.7)', fontFamily: 'Inter, sans-serif' }}
                      >
                        Number of Guests *
                      </label>
                      <CustomSelect
                        value={formData.guests}
                        onChange={(val) => updateField('guests', val)}
                        options={guestOptions}
                        placeholder="Select guests"
                        icon={Users}
                      />
                    </div>

                    <div className="space-y-2">
                      <label
                        className="text-xs tracking-widest uppercase"
                        style={{ color: 'rgba(201,168,76,0.7)', fontFamily: 'Inter, sans-serif' }}
                      >
                        Special Requests
                      </label>
                      <input
                        type="text"
                        value={formData.specialRequests}
                        onChange={(e) => updateField('specialRequests', e.target.value)}
                        placeholder="Allergies, occasions, preferences..."
                        className="w-full px-5 py-4 rounded-xl input-gold text-sm"
                        style={{ fontFamily: 'Inter, sans-serif' }}
                      />
                    </div>
                  </div>

                  {/* Error message */}
                  {errorMessage && (
                    <motion.p
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="text-sm text-center"
                      style={{ color: '#e57373', fontFamily: 'Inter, sans-serif' }}
                    >
                      {errorMessage}
                    </motion.p>
                  )}

                  {/* Submit */}
                  <div className="pt-4 flex flex-col sm:flex-row items-center gap-5 justify-between">
                    <p
                      className="text-xs leading-relaxed"
                      style={{ color: 'rgba(245,237,214,0.3)', fontFamily: 'Inter, sans-serif', maxWidth: '280px' }}
                    >
                      By submitting, you agree to our cancellation policy. Tables held for 15 minutes.
                    </p>
                    <motion.button
                      type="submit"
                      disabled={submitStatus === 'loading'}
                      whileHover={{ scale: 1.03, y: -2 }}
                      whileTap={{ scale: 0.97 }}
                      className="btn-gold-glow px-12 py-4 rounded-full text-sm tracking-[0.2em] uppercase font-medium flex items-center gap-3 relative overflow-hidden"
                      style={{ color: '#0D0D0D', fontFamily: 'Inter, sans-serif', minWidth: '200px', justifyContent: 'center' }}
                    >
                      {submitStatus === 'loading' ? (
                        <>
                          <Loader size={16} className="animate-spin" />
                          <span>Confirming...</span>
                        </>
                      ) : (
                        <span>Reserve Now</span>
                      )}
                    </motion.button>
                  </div>
                </motion.form>
              )}
            </AnimatePresence>
          </div>

          {/* Inner glow bottom */}
          <div
            className="h-px w-full"
            style={{ background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.15), transparent)' }}
          />
        </motion.div>

        {/* Info chips below form */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.4 }}
          className="flex flex-wrap justify-center gap-4 mt-8"
        >
          {[
            '🕐 Open Tue–Sun',
            '🍽️ Lunch: 12–3 PM',
            '🌙 Dinner: 7–11 PM',
            '📞 +91 98765 43210',
          ].map((item) => (
            <div
              key={item}
              className="glass rounded-full px-5 py-2 text-xs"
              style={{ color: 'rgba(245,237,214,0.5)', fontFamily: 'Inter, sans-serif' }}
            >
              {item}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
