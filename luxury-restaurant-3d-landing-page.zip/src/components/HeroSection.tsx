import { useRef, useEffect } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';

export default function HeroSection() {
  const containerRef = useRef<HTMLDivElement>(null);

  // Mouse parallax values
  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);

  const springConfig = { stiffness: 60, damping: 20, mass: 0.8 };
  const mouseX = useSpring(rawX, springConfig);
  const mouseY = useSpring(rawY, springConfig);

  // Background parallax (subtle, opposite direction)
  const bgX = useTransform(mouseX, [-1, 1], ['2%', '-2%']);
  const bgY = useTransform(mouseY, [-1, 1], ['2%', '-2%']);

  // Text parallax (follows mouse slightly)
  const textX = useTransform(mouseX, [-1, 1], ['-12px', '12px']);
  const textY = useTransform(mouseY, [-1, 1], ['-8px', '8px']);

  // Foreground decorative parallax (more intense)
  const decorX = useTransform(mouseX, [-1, 1], ['-25px', '25px']);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX / innerWidth - 0.5) * 2;
      const y = (e.clientY / innerHeight - 0.5) * 2;
      rawX.set(x);
      rawY.set(y);
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [rawX, rawY]);

  const scrollToReservation = () => {
    document.getElementById('reservation')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToMenu = () => {
    document.getElementById('menu')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section
      ref={containerRef}
      className="relative w-full h-screen overflow-hidden noise-overlay"
      style={{ background: '#0D0D0D' }}
    >
      {/* Cinematic Background Image with Parallax */}
      <motion.div
        className="absolute inset-0 w-[106%] h-[106%] -top-[3%] -left-[3%]"
        style={{ x: bgX, y: bgY }}
      >
        <img
          src="/images/hero-bg.jpg"
          alt="Aurum Fine Dining"
          className="w-full h-full object-cover"
        />
      </motion.div>

      {/* Dark cinematic overlay */}
      <div className="absolute inset-0 hero-gradient z-10" />

      {/* Subtle vignette */}
      <div
        className="absolute inset-0 z-10 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, transparent 40%, rgba(0,0,0,0.6) 100%)',
        }}
      />

      {/* Floating golden particles */}
      {[...Array(8)].map((_, i) => (
        <motion.div
          key={i}
          className="absolute w-1 h-1 rounded-full particle"
          style={{
            background: 'rgba(201, 168, 76, 0.6)',
            left: `${10 + i * 11}%`,
            top: `${20 + (i % 3) * 20}%`,
            animationDuration: `${4 + i * 0.7}s`,
            animationDelay: `${i * 0.4}s`,
            x: decorX,
          }}
        />
      ))}

      {/* Main Content */}
      <motion.div
        className="absolute inset-0 z-20 flex flex-col items-center justify-center text-center px-6"
        style={{ x: textX, y: textY }}
      >
        {/* Overline */}
        <motion.div
          initial={{ opacity: 0, letterSpacing: '0.3em' }}
          animate={{ opacity: 1, letterSpacing: '0.5em' }}
          transition={{ duration: 1.4, delay: 0.3 }}
          className="flex items-center gap-4 mb-6"
        >
          <div className="h-px w-12 bg-gradient-to-r from-transparent to-[#C9A84C]" />
          <span
            className="text-xs font-light tracking-[0.5em] uppercase"
            style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
          >
            Est. 2018 · Fine Dining
          </span>
          <div className="h-px w-12 bg-gradient-to-l from-transparent to-[#C9A84C]" />
        </motion.div>

        {/* Main Headline */}
        <motion.h1
          initial={{ opacity: 0, y: 60, filter: 'blur(12px)' }}
          animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
          transition={{ duration: 1.2, delay: 0.5, ease: [0.22, 1, 0.36, 1] }}
          className="font-cormorant font-light leading-none mb-2"
          style={{
            fontSize: 'clamp(4rem, 10vw, 9rem)',
            fontFamily: 'Cormorant Garamond, serif',
            color: '#F5EDD6',
            textShadow: '0 0 80px rgba(0,0,0,0.8)',
          }}
        >
          AURUM
        </motion.h1>

        {/* Italic subtitle line */}
        <motion.p
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.8 }}
          className="font-cormorant italic font-light mb-6"
          style={{
            fontSize: 'clamp(1.2rem, 3vw, 2.2rem)',
            fontFamily: 'Cormorant Garamond, serif',
            color: '#C9A84C',
            letterSpacing: '0.05em',
          }}
        >
          Where Every Plate Tells a Story
        </motion.p>

        {/* Gold divider */}
        <motion.div
          initial={{ scaleX: 0 }}
          animate={{ scaleX: 1 }}
          transition={{ duration: 1.2, delay: 1.0 }}
          className="gold-line w-32 mb-6"
        />

        {/* Sub-description */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.1 }}
          className="max-w-lg text-center font-light mb-10 leading-relaxed"
          style={{
            color: 'rgba(245, 237, 214, 0.65)',
            fontFamily: 'Inter, sans-serif',
            fontSize: 'clamp(0.85rem, 1.5vw, 1rem)',
            letterSpacing: '0.02em',
          }}
        >
          An intimate sanctuary of flavour, crafted from the world's rarest ingredients.
          A culinary journey unlike any other.
        </motion.p>

        {/* CTA Buttons */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 1.3 }}
          className="flex flex-col sm:flex-row gap-4 items-center"
        >
          {/* Primary CTA - Glass + Gold Glow */}
          <motion.button
            onClick={scrollToReservation}
            whileHover={{ scale: 1.04, y: -3 }}
            whileTap={{ scale: 0.97 }}
            className="relative group px-10 py-4 rounded-full text-sm tracking-[0.2em] uppercase font-medium overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, #C9A84C, #E8C96D, #C9A84C)',
              color: '#0D0D0D',
              fontFamily: 'Inter, sans-serif',
              boxShadow: '0 0 40px rgba(201,168,76,0.5), 0 0 80px rgba(201,168,76,0.2)',
              letterSpacing: '0.2em',
            }}
          >
            <span className="relative z-10">Reserve a Table</span>
            {/* Shimmer sweep on hover */}
            <motion.div
              className="absolute inset-0 opacity-0 group-hover:opacity-100"
              style={{
                background: 'linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent)',
              }}
              animate={{ x: ['-100%', '200%'] }}
              transition={{ duration: 1.5, repeat: Infinity, repeatDelay: 0.5 }}
            />
          </motion.button>

          {/* Secondary CTA - Outline glass */}
          <motion.button
            onClick={scrollToMenu}
            whileHover={{ scale: 1.04, y: -3 }}
            whileTap={{ scale: 0.97 }}
            className="glass px-10 py-4 rounded-full text-sm tracking-[0.2em] uppercase font-light"
            style={{
              color: '#F5EDD6',
              fontFamily: 'Inter, sans-serif',
              letterSpacing: '0.2em',
            }}
          >
            View Menu
          </motion.button>
        </motion.div>
      </motion.div>

      {/* Bottom scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 2, duration: 1 }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2 z-20 flex flex-col items-center gap-2"
      >
        <span
          className="text-xs tracking-[0.3em] uppercase"
          style={{ color: 'rgba(201,168,76,0.6)', fontFamily: 'Inter, sans-serif' }}
        >
          Scroll
        </span>
        <motion.div
          className="w-px h-10 origin-top"
          style={{ background: 'linear-gradient(to bottom, #C9A84C, transparent)' }}
          animate={{ scaleY: [0.3, 1, 0.3] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        />
      </motion.div>

      {/* Top Nav strip */}
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 1, delay: 0.2 }}
        className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-8 md:px-16 py-6"
      >
        <div
          className="font-cormorant font-light tracking-[0.3em] text-lg"
          style={{ color: '#C9A84C', fontFamily: 'Cormorant Garamond, serif' }}
        >
          AURUM
        </div>
        <div className="hidden md:flex items-center gap-8">
          {['Experience', 'Menu', 'Reserve', 'Contact'].map((item) => (
            <button
              key={item}
              onClick={() => {
                const id = item.toLowerCase() === 'reserve' ? 'reservation' :
                           item.toLowerCase() === 'contact' ? 'footer' :
                           item.toLowerCase() === 'experience' ? 'experience' : 'menu';
                document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="text-xs tracking-[0.2em] uppercase font-light transition-colors duration-300 hover:text-[#C9A84C]"
              style={{ color: 'rgba(245,237,214,0.6)', fontFamily: 'Inter, sans-serif' }}
            >
              {item}
            </button>
          ))}
        </div>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.96 }}
          onClick={scrollToReservation}
          className="hidden md:block glass-gold px-5 py-2 rounded-full text-xs tracking-[0.15em] uppercase"
          style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
        >
          Book Now
        </motion.button>
      </motion.nav>
    </section>
  );
}
