import { useRef } from 'react';
import { motion, useScroll, useTransform, useSpring } from 'framer-motion';

const stats = [
  { value: '12+', label: 'Years of Excellence' },
  { value: '98%', label: 'Guest Satisfaction' },
  { value: '3', label: 'Michelin Stars' },
  { value: '200+', label: 'Curated Wines' },
];

export default function ExperienceSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  });

  const smoothProgress = useSpring(scrollYProgress, { stiffness: 60, damping: 20 });

  const imageScale = useTransform(smoothProgress, [0, 0.4, 0.7], [0.85, 1, 1.03]);
  const imageOpacity = useTransform(smoothProgress, [0, 0.25, 0.7], [0, 1, 1]);

  const textY = useTransform(smoothProgress, [0.05, 0.4], [60, 0]);
  const textOpacity = useTransform(smoothProgress, [0.05, 0.35], [0, 1]);

  const taglineY = useTransform(smoothProgress, [0.12, 0.45], [50, 0]);
  const taglineOpacity = useTransform(smoothProgress, [0.12, 0.4], [0, 1]);

  const statsY = useTransform(smoothProgress, [0.25, 0.55], [40, 0]);
  const statsOpacity = useTransform(smoothProgress, [0.25, 0.5], [0, 1]);

  return (
    <section
      id="experience"
      ref={sectionRef}
      className="relative w-full bg-[#0D0D0D] py-32 overflow-hidden"
    >
      {/* Ambient glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[300px] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center, rgba(201,168,76,0.07) 0%, transparent 70%)',
          filter: 'blur(40px)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Label */}
        <motion.div
          style={{ y: textY, opacity: textOpacity }}
          className="flex items-center gap-4 mb-16"
        >
          <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#C9A84C]" />
          <span
            className="text-xs tracking-[0.45em] uppercase"
            style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
          >
            The Experience
          </span>
        </motion.div>

        {/* Main layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 lg:gap-24 items-center">
          {/* Left: Text Content */}
          <div className="space-y-8">
            <motion.div style={{ y: textY, opacity: textOpacity }}>
              <h2
                className="font-light leading-tight"
                style={{
                  fontSize: 'clamp(2.5rem, 5vw, 4.5rem)',
                  fontFamily: 'Cormorant Garamond, serif',
                  color: '#F5EDD6',
                  lineHeight: 1.1,
                }}
              >
                Crafted with the{' '}
                <span
                  className="italic shimmer-gold block"
                  style={{ lineHeight: 1.1 }}
                >
                  World's Finest
                </span>
              </h2>
            </motion.div>

            <motion.div style={{ y: taglineY, opacity: taglineOpacity }}>
              <p
                className="leading-relaxed font-light"
                style={{
                  color: 'rgba(245, 237, 214, 0.65)',
                  fontFamily: 'Inter, sans-serif',
                  fontSize: '1rem',
                  lineHeight: 1.8,
                }}
              >
                Every dish at Aurum is a meditation on perfection. We source{' '}
                <span style={{ color: '#C9A84C' }}>A5 Wagyu from Miyazaki</span>,
                truffles from Périgord, and saffron from Kashmir — ingredients that carry the
                weight of the world's most extraordinary terroirs.
              </p>
            </motion.div>

            <motion.div style={{ y: taglineY, opacity: taglineOpacity }}>
              <p
                style={{
                  color: 'rgba(245, 237, 214, 0.5)',
                  fontFamily: 'Inter, sans-serif',
                  fontSize: '0.9rem',
                  lineHeight: 1.9,
                }}
              >
                Our chef, trained across three continents, transforms these treasures into
                compositions that engage all five senses. Each evening at Aurum is a private
                performance — designed exclusively for you.
              </p>
            </motion.div>

            {/* Elegant quote */}
            <motion.div
              style={{ y: taglineY, opacity: taglineOpacity }}
              className="glass-gold rounded-2xl p-6"
            >
              <div
                style={{
                  borderLeft: '2px solid #C9A84C',
                  paddingLeft: '1.25rem',
                }}
              >
                <p
                  className="italic"
                  style={{
                    color: '#E8C96D',
                    fontFamily: 'Cormorant Garamond, serif',
                    fontSize: '1.25rem',
                    lineHeight: 1.7,
                  }}
                >
                  "To dine at Aurum is to understand that food, at its highest expression,
                  is pure poetry."
                </p>
                <p
                  className="mt-3 text-xs tracking-widest uppercase"
                  style={{ color: 'rgba(201,168,76,0.6)', fontFamily: 'Inter, sans-serif' }}
                >
                  — Chef Alessandro Moretti, Head Chef
                </p>
              </div>
            </motion.div>
          </div>

          {/* Right: 3D Zoom Image */}
          <div className="relative flex items-center justify-center">
            <motion.div
              style={{ opacity: imageOpacity }}
              className="absolute inset-0 rounded-3xl pointer-events-none"
            >
              <div
                style={{
                  position: 'absolute',
                  inset: 0,
                  background: 'radial-gradient(ellipse at center, rgba(201,168,76,0.15) 0%, transparent 70%)',
                  filter: 'blur(30px)',
                  borderRadius: '1.5rem',
                }}
              />
            </motion.div>

            <motion.div
              style={{
                scale: imageScale,
                opacity: imageOpacity,
                perspective: 1200,
              }}
              className="relative w-full rounded-3xl overflow-hidden gold-border-glow"
            >
              <img
                src="/images/experience-dish.jpg"
                alt="Signature Dish"
                className="w-full object-cover"
                style={{ aspectRatio: '4/5', objectFit: 'cover', display: 'block' }}
              />
              <div
                className="absolute bottom-0 left-0 right-0 h-1/3"
                style={{
                  background: 'linear-gradient(to top, rgba(13,13,13,0.85), transparent)',
                }}
              />
              <div className="absolute bottom-6 left-6 right-6 glass rounded-xl p-4">
                <p
                  className="italic text-lg"
                  style={{ color: '#E8C96D', fontFamily: 'Cormorant Garamond, serif' }}
                >
                  Signature Tasting Menu
                </p>
                <p
                  className="text-xs tracking-wider mt-1"
                  style={{ color: 'rgba(245,237,214,0.5)', fontFamily: 'Inter, sans-serif' }}
                >
                  7 courses · Chef's selection
                </p>
              </div>
            </motion.div>
          </div>
        </div>

        {/* Stats Row */}
        <motion.div
          style={{ y: statsY, opacity: statsOpacity }}
          className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-24"
        >
          {stats.map((stat, i) => (
            <motion.div
              key={stat.label}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.12, duration: 0.7 }}
              className="glass rounded-2xl p-6 text-center gold-border-glow hover:bg-white/[0.06] transition-all duration-300"
            >
              <div
                className="font-light text-4xl mb-1 shimmer-gold"
                style={{ fontFamily: 'Cormorant Garamond, serif' }}
              >
                {stat.value}
              </div>
              <div
                className="text-xs tracking-widest uppercase"
                style={{ color: 'rgba(245,237,214,0.4)', fontFamily: 'Inter, sans-serif' }}
              >
                {stat.label}
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
