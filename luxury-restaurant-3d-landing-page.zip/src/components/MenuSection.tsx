import { useState, useRef, useCallback } from 'react';
import { motion, AnimatePresence, useMotionValue, useSpring, useTransform } from 'framer-motion';

interface MenuItem {
  name: string;
  description: string;
  ingredients: string;
  price: string;
  image: string;
  tag?: string;
}

const menuData: Record<string, MenuItem[]> = {
  Starters: [
    {
      name: 'Caviar & Crème',
      description: 'Oscietra caviar atop hand-whipped crème fraîche',
      ingredients: 'Oscietra Caviar · Blinis · Crème Fraîche · Dill Oil · Lemon Zest',
      price: '₹4,200',
      image: '/images/menu-starter.jpg',
      tag: 'Chef\'s Pick',
    },
    {
      name: 'Truffle Velouté',
      description: 'Black truffle soup with gold leaf & crispy prosciutto',
      ingredients: 'Périgord Truffle · Parmesan · Cream · Prosciutto · Edible Gold',
      price: '₹2,800',
      image: '/images/menu-starter.jpg',
    },
    {
      name: 'Seared Foie Gras',
      description: 'Pan-seared foie gras with berry reduction and brioche toast',
      ingredients: 'Duck Foie Gras · Brioche · Strawberry Reduction · Micro Basil',
      price: '₹3,600',
      image: '/images/menu-starter.jpg',
      tag: 'Signature',
    },
  ],
  Mains: [
    {
      name: 'A5 Wagyu Filet',
      description: 'Miyazaki A5 Wagyu with truffle jus and seasonal vegetables',
      ingredients: 'Miyazaki A5 Wagyu · Truffle Jus · Heirloom Carrots · Asparagus · Bone Marrow',
      price: '₹12,500',
      image: '/images/menu-main.jpg',
      tag: 'Premium',
    },
    {
      name: 'Lobster Thermidor',
      description: 'Whole Maine lobster with saffron beurre blanc',
      ingredients: 'Maine Lobster · Saffron · Beurre Blanc · Tarragon · Cognac',
      price: '₹9,800',
      image: '/images/menu-main.jpg',
      tag: 'Bestseller',
    },
    {
      name: 'Lamb Rack en Croûte',
      description: 'New Zealand lamb with herb crust and pomme purée',
      ingredients: 'Lamb Rack · Herb Crust · Pomme Purée · Red Wine Jus · Rosemary',
      price: '₹7,200',
      image: '/images/menu-main.jpg',
    },
  ],
  Drinks: [
    {
      name: 'The Golden Hour',
      description: 'Aged whisky with honey syrup and saffron foam',
      ingredients: 'Macallan 18yr · Raw Honey · Kashmiri Saffron · Orange Bitters · Ice Sphere',
      price: '₹3,400',
      image: '/images/menu-drink.jpg',
      tag: 'Signature',
    },
    {
      name: 'Champagne Rosé',
      description: 'Vintage Billecart-Salmon Brut Rosé',
      ingredients: 'Billecart-Salmon · Pinot Noir · Chardonnay · Côte des Blancs',
      price: '₹8,500',
      image: '/images/menu-drink.jpg',
    },
    {
      name: 'Aurum Negroni',
      description: 'House-infused Campari with 24-karat gold flakes',
      ingredients: 'Hendricks Gin · Campari · Sweet Vermouth · Gold Flakes · Orange Peel',
      price: '₹2,800',
      image: '/images/menu-drink.jpg',
    },
  ],
};

const categories = ['Starters', 'Mains', 'Drinks'] as const;

// 3D Tilt Card Component
function MenuCard({ item, index }: { item: MenuItem; index: number }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  const rawX = useMotionValue(0);
  const rawY = useMotionValue(0);

  const springX = useSpring(rawX, { stiffness: 200, damping: 20 });
  const springY = useSpring(rawY, { stiffness: 200, damping: 20 });

  const rotateX = useTransform(springY, [-0.5, 0.5], [8, -8]);
  const rotateY = useTransform(springX, [-0.5, 0.5], [-8, 8]);
  const glareX = useTransform(springX, [-0.5, 0.5], ['0%', '100%']);
  const glareY = useTransform(springY, [-0.5, 0.5], ['0%', '100%']);

  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    rawX.set(x);
    rawY.set(y);
  }, [rawX, rawY]);

  const handleMouseLeave = useCallback(() => {
    rawX.set(0);
    rawY.set(0);
    setIsHovered(false);
  }, [rawX, rawY]);

  return (
    <motion.div
      ref={cardRef}
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30, scale: 0.95 }}
      transition={{ delay: index * 0.1, duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={handleMouseLeave}
      style={{
        rotateX,
        rotateY,
        transformStyle: 'preserve-3d',
        perspective: 1000,
      }}
      className="relative cursor-pointer"
    >
      <div
        className="glass rounded-2xl overflow-hidden gold-border-glow group transition-all duration-500"
        style={{
          transformStyle: 'preserve-3d',
          boxShadow: isHovered
            ? '0 25px 80px rgba(0,0,0,0.5), 0 0 40px rgba(201,168,76,0.1)'
            : '0 8px 30px rgba(0,0,0,0.3)',
          transition: 'box-shadow 0.4s ease',
        }}
      >
        {/* Card Image */}
        <div className="relative overflow-hidden" style={{ aspectRatio: '16/10' }}>
          <motion.img
            src={item.image}
            alt={item.name}
            className="w-full h-full object-cover"
            animate={{ scale: isHovered ? 1.08 : 1 }}
            transition={{ duration: 0.6, ease: 'easeOut' }}
          />

          {/* Dark overlay on hover */}
          <motion.div
            className="absolute inset-0"
            style={{
              background: 'linear-gradient(to top, rgba(13,13,13,0.95) 0%, rgba(13,13,13,0.3) 60%, transparent 100%)',
            }}
            animate={{ opacity: isHovered ? 1 : 0.6 }}
            transition={{ duration: 0.4 }}
          />

          {/* Glare effect */}
          <motion.div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: `radial-gradient(circle at ${glareX} ${glareY}, rgba(255,255,255,0.06) 0%, transparent 60%)`,
              opacity: isHovered ? 1 : 0,
            }}
          />

          {/* Tag badge */}
          {item.tag && (
            <div
              className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs tracking-widest uppercase"
              style={{
                background: 'linear-gradient(135deg, #C9A84C, #E8C96D)',
                color: '#0D0D0D',
                fontFamily: 'Inter, sans-serif',
                fontSize: '0.65rem',
                fontWeight: 600,
              }}
            >
              {item.tag}
            </div>
          )}

          {/* Ingredients reveal on hover */}
          <motion.div
            className="absolute bottom-0 left-0 right-0 p-5"
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: isHovered ? 0 : 20, opacity: isHovered ? 1 : 0 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          >
            <p
              className="text-xs leading-relaxed"
              style={{ color: 'rgba(201,168,76,0.85)', fontFamily: 'Inter, sans-serif', letterSpacing: '0.05em' }}
            >
              {item.ingredients}
            </p>
          </motion.div>
        </div>

        {/* Card Content */}
        <div className="p-6">
          <div className="flex items-start justify-between mb-2">
            <h3
              className="font-light leading-tight"
              style={{
                fontFamily: 'Cormorant Garamond, serif',
                fontSize: '1.35rem',
                color: '#F5EDD6',
              }}
            >
              {item.name}
            </h3>
            <span
              className="font-light ml-4 shrink-0"
              style={{
                fontFamily: 'Cormorant Garamond, serif',
                fontSize: '1.2rem',
                color: '#C9A84C',
              }}
            >
              {item.price}
            </span>
          </div>
          <p
            className="text-sm leading-relaxed"
            style={{ color: 'rgba(245,237,214,0.45)', fontFamily: 'Inter, sans-serif' }}
          >
            {item.description}
          </p>

          {/* Bottom gold line reveal */}
          <motion.div
            className="mt-4 h-px"
            style={{ background: 'linear-gradient(90deg, #C9A84C, transparent)' }}
            animate={{ scaleX: isHovered ? 1 : 0, originX: 0 }}
            transition={{ duration: 0.4 }}
          />
        </div>
      </div>
    </motion.div>
  );
}

export default function MenuSection() {
  const [activeCategory, setActiveCategory] = useState<string>('Starters');

  return (
    <section id="menu" className="relative w-full bg-[#0D0D0D] py-28 overflow-hidden">
      {/* Background ambient */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at 50% 0%, rgba(201,168,76,0.04) 0%, transparent 60%)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center gap-4 mb-5">
            <div className="h-px w-16 bg-gradient-to-r from-transparent to-[#C9A84C]" />
            <span
              className="text-xs tracking-[0.45em] uppercase"
              style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
            >
              Our Menu
            </span>
            <div className="h-px w-16 bg-gradient-to-l from-transparent to-[#C9A84C]" />
          </div>
          <h2
            className="font-light"
            style={{
              fontFamily: 'Cormorant Garamond, serif',
              fontSize: 'clamp(2.5rem, 5vw, 4rem)',
              color: '#F5EDD6',
              lineHeight: 1.1,
            }}
          >
            A Symphony of <span className="italic shimmer-gold">Flavours</span>
          </h2>
        </motion.div>

        {/* Category Tabs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="flex items-center justify-center gap-2 mb-14"
        >
          <div className="glass rounded-full p-1.5 flex gap-1">
            {categories.map((cat) => (
              <motion.button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className="relative px-8 py-3 rounded-full text-sm tracking-[0.1em] uppercase transition-colors duration-300"
                style={{
                  fontFamily: 'Inter, sans-serif',
                  color: activeCategory === cat ? '#0D0D0D' : 'rgba(245,237,214,0.5)',
                  fontWeight: activeCategory === cat ? 500 : 300,
                  position: 'relative',
                }}
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.97 }}
              >
                {activeCategory === cat && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 rounded-full"
                    style={{ background: 'linear-gradient(135deg, #C9A84C, #E8C96D)' }}
                    transition={{ type: 'spring', stiffness: 400, damping: 30 }}
                  />
                )}
                <span className="relative z-10">{cat}</span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Menu Cards Grid */}
        <AnimatePresence mode="wait">
          <motion.div
            key={activeCategory}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            style={{ perspective: '1200px' }}
          >
            {menuData[activeCategory].map((item, i) => (
              <MenuCard key={item.name} item={item} index={i} />
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="text-center mt-16"
        >
          <p
            className="mb-6 text-sm"
            style={{ color: 'rgba(245,237,214,0.4)', fontFamily: 'Inter, sans-serif' }}
          >
            Full menu available upon reservation. Seasonal items may vary.
          </p>
          <motion.button
            whileHover={{ scale: 1.04, y: -2 }}
            whileTap={{ scale: 0.97 }}
            onClick={() => document.getElementById('reservation')?.scrollIntoView({ behavior: 'smooth' })}
            className="glass-gold px-10 py-4 rounded-full text-sm tracking-[0.2em] uppercase"
            style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
          >
            Reserve & Dine
          </motion.button>
        </motion.div>
      </div>
    </section>
  );
}
