import { useEffect, useRef } from 'react';

export default function CustomCursor() {
  const dotRef = useRef<HTMLDivElement>(null);
  const ringRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    let dotX = 0, dotY = 0;
    let ringX = 0, ringY = 0;
    let animId: number;

    const moveDot = (e: MouseEvent) => {
      dotX = e.clientX;
      dotY = e.clientY;
    };

    const animate = () => {
      // Ring follows with lag
      ringX += (dotX - ringX) * 0.12;
      ringY += (dotY - ringY) * 0.12;

      if (dotRef.current) {
        dotRef.current.style.transform = `translate(${dotX}px, ${dotY}px) translate(-50%, -50%)`;
      }
      if (ringRef.current) {
        ringRef.current.style.transform = `translate(${ringX}px, ${ringY}px) translate(-50%, -50%)`;
      }

      animId = requestAnimationFrame(animate);
    };

    // Scale on hover
    const handleEnter = () => {
      if (dotRef.current) {
        dotRef.current.style.width = '6px';
        dotRef.current.style.height = '6px';
      }
      if (ringRef.current) {
        ringRef.current.style.width = '56px';
        ringRef.current.style.height = '56px';
        ringRef.current.style.borderColor = 'rgba(201,168,76,0.8)';
      }
    };

    const handleLeave = () => {
      if (dotRef.current) {
        dotRef.current.style.width = '12px';
        dotRef.current.style.height = '12px';
      }
      if (ringRef.current) {
        ringRef.current.style.width = '40px';
        ringRef.current.style.height = '40px';
        ringRef.current.style.borderColor = 'rgba(201,168,76,0.5)';
      }
    };

    window.addEventListener('mousemove', moveDot);
    animId = requestAnimationFrame(animate);

    // Add hover on interactive elements
    const interactives = document.querySelectorAll('a, button, input, select, textarea, [role="button"]');
    interactives.forEach((el) => {
      el.addEventListener('mouseenter', handleEnter);
      el.addEventListener('mouseleave', handleLeave);
    });

    return () => {
      window.removeEventListener('mousemove', moveDot);
      cancelAnimationFrame(animId);
    };
  }, []);

  return (
    <>
      <div
        ref={dotRef}
        className="custom-cursor"
        style={{ position: 'fixed', top: 0, left: 0, pointerEvents: 'none' }}
      />
      <div
        ref={ringRef}
        className="custom-cursor-ring"
        style={{ position: 'fixed', top: 0, left: 0, pointerEvents: 'none' }}
      />
    </>
  );
}
