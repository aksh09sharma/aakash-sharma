import { motion } from 'framer-motion';

// Instagram SVG Icon
const InstagramIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
    <circle cx="12" cy="12" r="4.5" />
    <circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none" />
  </svg>
);

// WhatsApp SVG Icon
const WhatsAppIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

// Email SVG Icon
const EmailIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" />
    <polyline points="22,6 12,13 2,6" />
  </svg>
);

const socialLinks = [
  {
    name: 'Instagram',
    href: 'https://instagram.com',
    icon: InstagramIcon,
    handle: '@aurum.dining',
  },
  {
    name: 'WhatsApp',
    href: 'https://wa.me/919876543210',
    icon: WhatsAppIcon,
    handle: '+91 98765 43210',
  },
  {
    name: 'Email',
    href: 'mailto:reservations@aurum.in',
    icon: EmailIcon,
    handle: 'reservations@aurum.in',
  },
];

const navLinks = [
  { label: 'Experience', id: 'experience' },
  { label: 'Menu', id: 'menu' },
  { label: 'Reservations', id: 'reservation' },
];

export default function FooterSection() {
  return (
    <footer id="footer" className="relative bg-[#080808] pt-24 pb-10 overflow-hidden">
      {/* Top gold line */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{ background: 'linear-gradient(90deg, transparent, rgba(201,168,76,0.4), transparent)' }}
      />

      {/* Ambient glow */}
      <div
        className="absolute top-0 left-1/2 -translate-x-1/2 w-[500px] h-[200px] pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at center top, rgba(201,168,76,0.06) 0%, transparent 70%)',
          filter: 'blur(30px)',
        }}
      />

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        {/* Main Footer Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-16 mb-20">
          {/* Col 1: Brand */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7 }}
            className="space-y-6"
          >
            <div>
              <div
                className="font-light tracking-[0.4em] text-2xl mb-2"
                style={{ fontFamily: 'Cormorant Garamond, serif', color: '#C9A84C' }}
              >
                AURUM
              </div>
              <div
                className="text-xs tracking-[0.3em] uppercase"
                style={{ color: 'rgba(245,237,214,0.3)', fontFamily: 'Inter, sans-serif' }}
              >
                Fine Dining · Est. 2018
              </div>
            </div>

            <p
              className="text-sm leading-relaxed"
              style={{ color: 'rgba(245,237,214,0.4)', fontFamily: 'Inter, sans-serif', maxWidth: '280px' }}
            >
              A sanctuary of culinary artistry in the heart of the city. Where extraordinary
              ingredients meet masterful technique.
            </p>

            {/* Social Icons */}
            <div className="flex gap-3">
              {socialLinks.map((social) => (
                <motion.a
                  key={social.name}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  whileHover={{ scale: 1.1, y: -3 }}
                  whileTap={{ scale: 0.95 }}
                  className="w-10 h-10 glass rounded-full flex items-center justify-center group"
                  style={{
                    color: 'rgba(245,237,214,0.4)',
                    border: '1px solid rgba(201,168,76,0.15)',
                    transition: 'all 0.3s ease',
                  }}
                  title={social.name}
                >
                  <span
                    className="group-hover:text-[#C9A84C] transition-colors duration-300"
                    style={{ color: 'rgba(245,237,214,0.5)' }}
                  >
                    <social.icon />
                  </span>
                </motion.a>
              ))}
            </div>
          </motion.div>

          {/* Col 2: Contact & Social Details */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="space-y-8"
          >
            <div>
              <div
                className="text-xs tracking-[0.3em] uppercase mb-5"
                style={{ color: 'rgba(201,168,76,0.6)', fontFamily: 'Inter, sans-serif' }}
              >
                Contact Us
              </div>
              <div className="space-y-4">
                {socialLinks.map((social) => (
                  <a
                    key={social.name}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-3 group"
                  >
                    <span
                      className="group-hover:text-[#C9A84C] transition-colors duration-300"
                      style={{ color: 'rgba(201,168,76,0.5)' }}
                    >
                      <social.icon />
                    </span>
                    <span
                      className="text-sm group-hover:text-[#C9A84C] transition-colors duration-300"
                      style={{ color: 'rgba(245,237,214,0.4)', fontFamily: 'Inter, sans-serif' }}
                    >
                      {social.handle}
                    </span>
                  </a>
                ))}
              </div>
            </div>

            <div>
              <div
                className="text-xs tracking-[0.3em] uppercase mb-5"
                style={{ color: 'rgba(201,168,76,0.6)', fontFamily: 'Inter, sans-serif' }}
              >
                Hours
              </div>
              <div
                className="space-y-2 text-sm"
                style={{ color: 'rgba(245,237,214,0.4)', fontFamily: 'Inter, sans-serif' }}
              >
                <div className="flex justify-between max-w-[220px]">
                  <span>Lunch</span>
                  <span style={{ color: 'rgba(245,237,214,0.6)' }}>12:00 – 3:00 PM</span>
                </div>
                <div className="flex justify-between max-w-[220px]">
                  <span>Dinner</span>
                  <span style={{ color: 'rgba(245,237,214,0.6)' }}>7:00 – 11:00 PM</span>
                </div>
                <div className="flex justify-between max-w-[220px]">
                  <span>Monday</span>
                  <span style={{ color: 'rgba(201,168,76,0.5)' }}>Closed</span>
                </div>
              </div>
            </div>

            {/* Quick Nav */}
            <div>
              <div
                className="text-xs tracking-[0.3em] uppercase mb-5"
                style={{ color: 'rgba(201,168,76,0.6)', fontFamily: 'Inter, sans-serif' }}
              >
                Navigate
              </div>
              <div className="flex flex-wrap gap-3">
                {navLinks.map((link) => (
                  <button
                    key={link.label}
                    onClick={() => document.getElementById(link.id)?.scrollIntoView({ behavior: 'smooth' })}
                    className="text-xs tracking-wider hover:text-[#C9A84C] transition-colors duration-300"
                    style={{ color: 'rgba(245,237,214,0.35)', fontFamily: 'Inter, sans-serif' }}
                  >
                    {link.label}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>

          {/* Col 3: Map Embed */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="space-y-4"
          >
            <div
              className="text-xs tracking-[0.3em] uppercase mb-5"
              style={{ color: 'rgba(201,168,76,0.6)', fontFamily: 'Inter, sans-serif' }}
            >
              Find Us
            </div>

            {/* Map Placeholder */}
            <div
              className="relative rounded-2xl overflow-hidden gold-border-glow"
              style={{ height: '220px' }}
            >
              {/**
               * GOOGLE MAPS EMBED
               * Replace the src below with your actual Google Maps embed URL:
               * 1. Go to Google Maps → Find your location
               * 2. Click Share → Embed a map → Copy HTML
               * 3. Paste the src URL from the <iframe> here
               * Example: https://www.google.com/maps/embed?pb=!1m18...
               */}
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.9748499!2d72.8776559!3d19.0759837!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c6306644edc1%3A0x5da4ed8f8d648c69!2sMumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1699999999999!5m2!1sen!2sin"
                width="100%"
                height="220"
                style={{ border: 0, filter: 'grayscale(80%) invert(90%) contrast(85%) brightness(50%)' }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Aurum Restaurant Location"
              />
              {/* Map overlay for brand */}
              <div
                className="absolute bottom-0 left-0 right-0 p-4 glass"
                style={{ borderTop: '1px solid rgba(201,168,76,0.15)' }}
              >
                <p
                  className="text-xs font-medium"
                  style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
                >
                  Aurum Fine Dining
                </p>
                <p
                  className="text-xs mt-0.5"
                  style={{ color: 'rgba(245,237,214,0.4)', fontFamily: 'Inter, sans-serif' }}
                >
                  12, Marine Drive, Mumbai 400020
                </p>
              </div>
            </div>

            <motion.button
              whileHover={{ scale: 1.03, y: -2 }}
              whileTap={{ scale: 0.97 }}
              onClick={() => window.open('https://maps.google.com', '_blank')}
              className="w-full glass-gold rounded-xl py-3 text-xs tracking-widest uppercase text-center"
              style={{ color: '#C9A84C', fontFamily: 'Inter, sans-serif' }}
            >
              Get Directions
            </motion.button>
          </motion.div>
        </div>

        {/* Bottom Bar */}
        <div
          className="pt-8"
          style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p
              className="text-xs"
              style={{ color: 'rgba(245,237,214,0.2)', fontFamily: 'Inter, sans-serif' }}
            >
              © {new Date().getFullYear()} Aurum Fine Dining. All rights reserved.
            </p>
            <div className="flex items-center gap-2">
              <div className="h-px w-8" style={{ background: 'rgba(201,168,76,0.3)' }} />
              <span
                className="text-xs tracking-[0.3em] uppercase"
                style={{ color: 'rgba(201,168,76,0.4)', fontFamily: 'Cormorant Garamond, serif', fontStyle: 'italic' }}
              >
                Crafted with Passion
              </span>
              <div className="h-px w-8" style={{ background: 'rgba(201,168,76,0.3)' }} />
            </div>
            <div className="flex gap-5">
              {['Privacy Policy', 'Terms'].map((item) => (
                <span
                  key={item}
                  className="text-xs cursor-pointer hover:text-[#C9A84C] transition-colors duration-300"
                  style={{ color: 'rgba(245,237,214,0.2)', fontFamily: 'Inter, sans-serif' }}
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
